import React, { useState } from "react";

export default function Home() {
  const [contactName, setContactName] = useState("Vishalakshi");
  const [contactPhone, setContactPhone] = useState("+91-9632543185");
  const [contactEmail, setContactEmail] = useState("info@nexcellent.com");

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <header className="bg-white shadow p-4 mb-8">
        <h1 className="text-3xl font-bold text-center text-blue-600">nXcellent TechSolutions Private Limited</h1>
        <p className="text-center text-gray-700 mt-2">Your Partner in Software Services and SAP Support</p>
      </header>
      
      <section id="about" className="bg-white p-8 rounded-xl shadow-lg mb-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">About Us</h2>
        <p className="text-gray-600">nXcellent TechSolutions specializes in delivering high-quality software services, application support & maintenance for SAP projects, and outsourcing trained and experienced resources to meet your business needs.</p>
      </section>
      
      <section id="services" className="bg-white p-8 rounded-xl shadow-lg mb-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Services</h2>
        <ul className="list-disc list-inside text-gray-600">
          <li><strong>Software Services:</strong> Custom software development, integration, and consulting</li>
          <li><strong>Application Support & Maintenance (SAP):</strong> End-to-end support and maintenance for SAP projects</li>
          <li><strong>Resource Outsourcing:</strong> Providing trained and experienced professionals for IT projects</li>
        </ul>
      </section>
      
      <section id="careers" className="bg-white p-8 rounded-xl shadow-lg mb-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Careers</h2>
        <p className="text-gray-600">Join our team and grow your career with us! Check our job openings and submit your application.</p>
      </section>
      
      <section id="contact" className="bg-white p-8 rounded-xl shadow-lg mb-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Contact Us</h2>
        <p className="text-gray-600">Feel free to reach out to us at:</p>
        <div className="mb-4">
          <label className="block text-gray-700 font-semibold">Contact Person:</label>
          <input type="text" value={contactName} onChange={(e) => setContactName(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 font-semibold">Email:</label>
          <input type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 font-semibold">Phone:</label>
          <input type="tel" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} className="w-full p-2 border rounded" />
        </div>
      </section>
      
      <footer className="text-center text-gray-500 mt-8">
        &copy; 2025 nXcellent TechSolutions Private Limited. All rights reserved.
      </footer>
    </div>
  );
}